# README

# This program is meant to allow a user to input their coffee order in return display thier order/ orders in a text file. 

# Step 1) Open the USERMANUAL.docx file 
	This file will explain how to launch the program and how it works. 

